def distance_in_ll(lat=0, earth_radius=6378.1370):
    from numpy import pi, cos
    circle_lon=2.*pi*earth_radius # length of one meridian
    onedeglat=(circle_lon/360.) # km in one degree of latitude

    proj_earth_radius=earth_radius*cos(lat*pi/180.)
    circle_lat=2.*pi*proj_earth_radius # length of circle of mean longitude
    onedeglon=(circle_lat/360.) # km in one degree of longitude

    return(onedeglon, onedeglat)
def region_box(site, site_lon, site_lat, box_size = 3 ):
    


    ## get approximate distance per degree lon/lat
    dlon, dlat = distance_in_ll(site_lat)

    ## make box around station
    lat_off = (box_size/dlat)/2
    lon_off = (box_size/dlon)/2
    limit = [site_lat-lat_off, site_lon-lon_off, site_lat+lat_off, site_lon+lon_off]

    return(limit)
def getGeeData(workspace,extent_gcs,s1_date,crs,tile_size = 606,url_jrc="JRC/GSW1_4/GlobalSurfaceWater",jrc_band = "occurrence",
               s1_band = "VV", url_s1="COPERNICUS/S1_GRD",download_s1=True,download_jrc=True):
    '''
    Download SAR and JRC water images to tiles (default 606 pixels)

    '''
    import ee
    ee.Initialize()
        
    ##Obtain the bouding box by user
    numbers = extent_gcs.split(',')
    s1_date = s1_date.split(',')

    # Assign the extracted numbers to variables
    x1, y1, x2, y2 = map(float, numbers)    
    bbox = ee.Geometry.BBox(x1,y1,x2,y2)
    #Download JRC
    
    # send the task for jrc on gee for processing. Establish a watching thread to update the status until the task is completed
    if(url_jrc != ""):
        try:
            datasetJRC = ee.Image(url_jrc).select(jrc_band).clip(bbox)
            proj = datasetJRC.projection().getInfo()
            if 'crs' in proj:
                proj_crs = proj['crs']
            elif 'wkt' in proj:
                proj_crs = proj['wkt']
            p = ee.Projection(proj_crs, proj['transform'])
            scale = p.nominalScale().getInfo()
            band = datasetJRC.getInfo()
            crs = band['crs']
            crs_transform = band['crs_transform']
            transform = proj['transform']
            print(scale,transform,crs)
            if download_jrc:
                
                task = ee.batch.Export.image.toDrive(
                    image= datasetJRC,
                    description= 'JCRwaterpixels',
                    region= bbox,
                    folder= 'AnyFolder',
                    scale= 10,
                    fileFormat= 'GeoTIFF',
                    maxPixels= 3784216672400,
                    crs= crs
                    )
                task.start()
                print(f"Export task started with ID: {task.id}")
                print(f"Export destination: JCRwaterpixels.tif in AnyFolder")
  
        except Exception as e:
            print(e)
    if(url_s1 != ""):

        s1ImgC = ee.ImageCollection(url_s1).select([s1_band,"angle"]) \
            .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV')) \
            .filter(ee.Filter.eq('instrumentMode', 'IW')) \
            .filterBounds(bbox) \
            .filterDate(s1_date[0],s1_date[1])
        # Function to calculate intersection area.
        
        def calculate_intersection_area(image):
            intersection = image.geometry().intersection(bbox, ee.ErrorMargin(1))
            intersection_area = intersection.area()
            return image.set('intersection_area', intersection_area)

        # Map the function over the filtered collection.
        with_area = s1ImgC.map(calculate_intersection_area)

        # Sort the collection by the intersection area.
        sorted_collection = with_area.sort('intersection_area', False)
        s1Img = sorted_collection.first()
        metadata = s1Img.getInfo()
        with open(os.path.join(workspace,'s1_metadata.json'), 'w') as json_file:
            json.dump(metadata, json_file, indent=4)
            print(f"Sentinel-1 image metadata is written to s1_metadata.json")
        s1Img = s1Img.clip(bbox).toFloat()
        s1Img = refined_lee(s1Img).select(s1_band)

        if download_s1:
            #s1Img = TerrainCorrection(s1Img)
            taskS1 = ee.batch.Export.image.toDrive(
                image= s1Img,
                description= 'S1_Lee_filter',
                region= bbox,
                folder= 'AnyFolder',
                scale= 10,
                fileFormat= 'GeoTIFF',
                maxPixels= 3784216672400,
                crs= crs
                )
            taskS1.start()
            print(f"Export task started with ID: {taskS1.id}")
            print(f"Export destination: s1_Lee_filter.tif in AnyFolder")