import cv2, ImageObject
from osgeo import gdal
import numpy as np

# Function to read a GeoTIFF image using GDAL
def read_geotiff(file_path):
    dataset = gdal.Open(file_path, gdal.GA_ReadOnly)
    band = dataset.GetRasterBand(1)  # Read the first band (assuming grayscale or single band image)
    geo_transform = dataset.GetGeoTransform()  # Get geotransform (spatial info)
    projection = dataset.GetProjection()       # Get projection (spatial reference)
    image = band.ReadAsArray()                 # Read the raster data as a NumPy array
    return image, geo_transform, projection, dataset

# Function to write the processed image to GeoTIFF using GDAL
def write_geotiff(file_path, image, geo_transform, projection, dataset):
    driver = gdal.GetDriverByName('GTiff')
    out_dataset = driver.Create(file_path, dataset.RasterXSize, dataset.RasterYSize, 1, gdal.GDT_Byte)
    out_dataset.SetGeoTransform(geo_transform)  # Set geotransform
    out_dataset.SetProjection(projection)       # Set projection
    out_band = out_dataset.GetRasterBand(1)
    out_band.WriteArray(image)                  # Write the image data
    out_band.FlushCache()                       # Save changes
    out_dataset = None                          # Close the file
def postProcess(inImg,
            outImg ,
            minObject = 100,
            minHoleSize = 10000):
    image, geo_transform, projection, dataset = read_geotiff(inImg)
    # Define the structuring element (kernel) for morphological closing
    kernel = np.ones((3, 3), np.uint8)
    print("Performing image morphology")
    print("closing")
    closed_image = cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel)
    print("opening")
    opened_image = cv2.morphologyEx(closed_image, cv2.MORPH_OPEN, kernel)
    
    print("Running image object filtering")
    
    input_image = ImageObject.Create2DArrayFromNumpy(opened_image)
    rm = ImageObject.RegionManagement(input_image)
    rm.regionGeneration()
    rm.removeSmallObjs(minObject,minHoleSize)
    out_image = rm.writeImage()
    outarray = ImageObject.imageToPyArray(out_image)    
    write_geotiff(outImg, outarray, geo_transform, projection, dataset)
    print(f"Postprocessed image written to {outImg}")



